from flask import Flask, request, jsonify
from flask_cors import CORS
import groq
import os
from deepface import DeepFace
import cv2
import numpy as np
import base64
from PIL import Image
import io

app = Flask(__name__)
CORS(app)

# Initialize Groq client - replace with your API key
client = groq.Groq(api_key="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")

# System message to define the chatbot's role and behavior
SYSTEM_MESSAGE = """You are a compassionate mental health support chatbot. Your role is to:
1. Provide empathetic and supportive responses
2. Listen actively and acknowledge feelings
3. Suggest healthy coping strategies when appropriate
4. Encourage professional help when needed
5. Maintain a warm and understanding tone
6. Never provide medical diagnoses or treatment advice
7. Always prioritize user safety and well-being

If someone expresses thoughts of self-harm or suicide, always respond with:
"I hear that you're going through a really difficult time. Your life matters, and help is available right now. Please contact emergency services or call the suicide prevention hotline at 988. Would you like me to provide more crisis resources?"
"""

@app.route('/chat', methods=['POST'])
def chat():
    try:
        data = request.json
        user_message = data.get('message', '')

        # Create chat completion with Groq
        completion = client.chat.completions.create(
            model="mixtral-8x7b-32768",  # or another available model
            messages=[
                {"role": "system", "content": SYSTEM_MESSAGE},
                {"role": "user", "content": user_message}
            ],
            temperature=0.7,
            max_tokens=500,
            top_p=1,
            stream=False
        )

        # Extract the response
        bot_response = completion.choices[0].message.content

        return jsonify({'response': bot_response})

    except Exception as e:
        print(f"Error: {str(e)}")
        return jsonify({
            'response': "I apologize, but I'm having trouble processing your message right now. Please try again."
        }), 500

@app.route('/detect-emotion', methods=['POST'])
def detect_emotion():
    try:
        # Get image data from the request
        image_data = request.json['image'].split(',')[1]
        image_bytes = base64.b64decode(image_data)
        
        # Convert to numpy array
        image = Image.open(io.BytesIO(image_bytes))
        image_np = np.array(image)
        
        # Analyze emotion
        result = DeepFace.analyze(image_np, actions=['emotion'], enforce_detection=False)
        
        # Get dominant emotion
        emotion = result[0]['dominant_emotion']
        emotions = result[0]['emotion']
        
        return jsonify({
            'dominant_emotion': emotion,
            'emotions': emotions
        })
    except Exception as e:
        print(f"Error: {str(e)}")
        return jsonify({
            'error': 'Failed to detect emotion'
        }), 500

if __name__ == '__main__':
    app.run(port=5000, debug=True)
