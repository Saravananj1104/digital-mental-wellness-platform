(function() {
  // Responsive Sidebar Navigation - by CodyHouse.co
  var searchInput = document.getElementsByClassName('js-cd-search')[0],
    navList = document.getElementsByClassName('js-cd-nav__list')[0];
  if( searchInput && navList) {
    var sidebar = document.getElementsByClassName('js-cd-side-nav')[0],
      mainHeader = document.getElementsByClassName('js-cd-main-header')[0],
      mobileNavTrigger = document.getElementsByClassName('js-cd-nav-trigger')[0],
      dropdownItems = document.getElementsByClassName('js-cd-item--has-children');
    
    //on resize, move search and top nav position according to window width
    var resizing = false;
    window.addEventListener('resize', function(){
      if(resizing) return;
      resizing = true;
      (!window.requestAnimationFrame) ? setTimeout(moveNavigation, 300) : window.requestAnimationFrame(moveNavigation);
    });
    window.dispatchEvent(new Event('resize'));//trigger the moveNavigation function

    //on mobile, open sidebar when clicking on menu icon
    mobileNavTrigger.addEventListener('click', function(event){
      event.preventDefault();
      var toggle = !Util.hasClass(sidebar, 'cd-side-nav--is-visible');
      if(toggle) expandSidebarItem();
      Util.toggleClass(sidebar, 'cd-side-nav--is-visible', toggle);
      Util.toggleClass(mobileNavTrigger, 'cd-nav-trigger--nav-is-visible', toggle);
    });

    // on mobile -> show subnavigation on click
    for(var i = 0; i < dropdownItems.length; i++) {
      (function(i){
        dropdownItems[i].children[0].addEventListener('click', function(event){
          if(checkMQ() == 'mobile') {
            event.preventDefault();
            var item = event.target.parentNode;
            Util.toggleClass(item, 'cd-side__item--expanded', !Util.hasClass(item, 'cd-side__item--expanded'));
          }
        });
      })(i);
    }
    
    //on desktop - differentiate between a user trying to hover over a dropdown item vs trying to navigate into a submenu's contents
    var listItems = sidebar.querySelectorAll('.js-cd-side__list > li');
    new menuAim({
      menu: sidebar,
      activate: function(row) {
        Util.addClass(row, 'hover');
      },
      deactivate: function(row) {
        Util.removeClass(row, 'hover');
      },
      exitMenu: function() {
        hideHoveredItems();
        return true;
      },
      rows: listItems,
      submenuSelector: '.js-cd-item--has-children',
    });

    function moveNavigation(){ // move searchInput and navList
      var mq = checkMQ();
      if ( mq == 'mobile' && !Util.hasClass(navList.parentNode, 'js-cd-side-nav') ) {
        detachElements();
        sidebar.appendChild(navList);
        sidebar.insertBefore(searchInput, sidebar.firstElementChild);
      } else if ( mq == 'desktop' && !Util.hasClass(navList.parentNode, 'js-cd-main-header') ) {
        detachElements();
        mainHeader.appendChild(navList);
        mainHeader.insertBefore(searchInput, mainHeader.firstElementChild.nextSibling);
      }
      checkSelected(mq);
      resizing = false;
    };

    function detachElements() { // remove element from DOM
      searchInput.parentNode.removeChild(searchInput);
      navList.parentNode.removeChild(navList);
    };

    function hideHoveredItems() { // exit sidebar -> hide dropdown
      var hoveredItems = sidebar.getElementsByClassName('hover');
      for(var i = 0; i < hoveredItems.length; i++) Util.removeClass(hoveredItems[i], 'hover');
    };

    function checkMQ() { // check if mobile or desktop device
      return window.getComputedStyle(mainHeader, '::before').getPropertyValue('content').replace(/'|"/g, "");
    };

    function expandSidebarItem() { // show dropdown of the selected sidebar item
      Util.addClass(sidebar.getElementsByClassName('cd-side__item--selected')[0], 'cd-side__item--expanded');
    };

    function checkSelected(mq) {
      // on desktop, remove expanded class from items (js-cd-item--has-children) that were expanded on mobile version
      if( mq == 'desktop' ) {
        for(var i = 0; i < dropdownItems.length; i++) Util.removeClass(dropdownItems[i], 'cd-side__item--expanded');
      };
    }
  }
}());
const moodSlider = document.getElementById('mood-slider');
const moodSolutionDiv = document.getElementById('mood-solution');
const emojiOptions = document.querySelectorAll('.emoji-option');

const moodSolutions = [
  "It's okay to feel this way. Try to relax and talk to someone close to you.",
  "Take a moment for yourself. A short walk or deep breathing could help.",
  "You're doing alright! Maybe try engaging in something creative or relaxing.",
  "Great! Keep the positive energy going. Consider doing something productive.",
  "Awesome! Keep up the positivity. Maybe you can spread the good vibes by helping others.",
  "That's awesome! Ride the excitement and try something new today!",
  "You're on the right track! Keep working toward your goals, you're doing great!",
  "It's okay to be unsure. Try to break things down one step at a time.",
  "Keep up the enthusiasm! It's a great time to start something new!",
  "It's okay to feel sad sometimes. Consider talking to a loved one or doing something you enjoy.",
  "Take a deep breath and try to relax. Consider taking some time to cool off.",
  "That's great! Keep spreading the positivity and laughter!"
];

moodSlider.addEventListener('input', function() {
  const index = moodSlider.value;
  moodSolutionDiv.innerHTML = `<p>${moodSolutions[index]}</p>`;

  // Update emoji labels to match slider position
  emojiOptions.forEach((option, i) => {
    if (i == index) {
      option.querySelector('label').style.transform = "scale(1.2)";
    } else {
      option.querySelector('label').style.transform = "scale(1)";
    }
  });
});
document.getElementById('recommendation-btn').addEventListener('click', function() {
  let mood = document.getElementById('mood-selector').value;
  let message = '';

  switch (mood) {
    case 'relaxed':
      message = 'Enjoy the Progressive Muscle Relaxation to enhance your relaxation!';
      break;
    case 'stressed':
      message = 'Try Deep Breathing Exercises to relieve stress.';
      break;
    case 'anxious':
      message = 'Mindfulness Meditation could help calm your mind.';
      break;
    case 'tired':
      message = 'Progressive Muscle Relaxation can help refresh your body and mind.';
      break;
    default:
      message = 'Take a moment to relax and breathe deeply.';
  }

  document.getElementById('mood-message').innerText = message;
});
document.getElementById('saveMoodButton').addEventListener('click', function() {
  const moodText = document.getElementById('moodText').value;
  const moodSelector = document.getElementById('moodSelector').value;

  // Save data in localStorage
  const moodData = { text: moodText, mood: moodSelector };
  localStorage.setItem('moodEntry', JSON.stringify(moodData));

  alert("Your mood has been saved!");
});

let timers = [
  { id: 1, time: 0, interval: null, isRunning: false },
  { id: 2, time: 0, interval: null, isRunning: false },
  { id: 3, time: 0, interval: null, isRunning: false }
];

function startStopTimer(timerId) {
  const timer = timers[timerId - 1];
  const timeDisplay = document.getElementById('time' + timerId);
  const button = document.getElementById('startStopBtn' + timerId);

  if (timer.isRunning) {
    // Stop the timer
    clearInterval(timer.interval);
    button.textContent = 'Start Timer';
  } else {
    // Start the timer
    timer.interval = setInterval(function() {
      timer.time++;
      let minutes = Math.floor(timer.time / 60);
      let seconds = timer.time % 60;
      timeDisplay.textContent = `Time: ${pad(minutes)}:${pad(seconds)}`;
    }, 1000);
    button.textContent = 'Stop Timer';
  }

  timer.isRunning = !timer.isRunning;
}

function pad(num) {
  return num < 10 ? '0' + num : num;
}

// Attach event listeners to the buttons
document.getElementById('startStopBtn1').addEventListener('click', function() { startStopTimer(1); });
document.getElementById('startStopBtn2').addEventListener('click', function() { startStopTimer(2); });
document.getElementById('startStopBtn3').addEventListener('click', function() { startStopTimer(3); });
document.getElementById('log-mood-btn').addEventListener('click', function () {
  const mood = document.getElementById('mood-select').value;
  const moodText = document.getElementById('mood-entry').value;
  const suggestionsList = document.getElementById('mood-suggestions-list');

  // Clear previous suggestions
  suggestionsList.innerHTML = '';

  // Check if the user entered their mood description
  if (!moodText.trim()) {
    suggestionsList.innerHTML = '<li>Please describe your mood in the text box above.</li>';
    return;
  }

  // Generate suggestions based on mood
  let suggestions = [];
  switch (mood) {
    case 'happy':
      suggestions = [
        'Share your positivity with someone by sending them a kind message.',
        'Celebrate your mood by doing something you enjoy!',
        'Write down what made you happy today to remember it later.',
      ];
      break;
    case 'sad':
      suggestions = [
        'Take some time for self-care, like watching your favorite movie.',
        'Talk to a close friend or family member about your feelings.',
        'Write down your thoughts to better understand them.',
      ];
      break;
    case 'stressed':
      suggestions = [
        'Try a 5-minute breathing exercise to relax your mind.',
        'Take a short break from your tasks and go for a walk.',
        'Organize your to-do list and focus on one thing at a time.',
      ];
      break;
    case 'anxious':
      suggestions = [
        'Practice grounding techniques like focusing on your breath.',
        'Listen to calming music or guided meditation.',
        'Write down your worries to help release them.',
      ];
      break;
    case 'tired':
      suggestions = [
        'Take a short nap if you can, or relax with a warm drink.',
        'Step outside for fresh air to re-energize.',
        'Make sure to prioritize rest and get a good night’s sleep tonight.',
      ];
      break;
  }

  // Display suggestions
  suggestions.forEach((suggestion) => {
    const listItem = document.createElement('li');
    listItem.textContent = suggestion;
    suggestionsList.appendChild(listItem);
  });
});
const techniqueLinks = document.querySelectorAll('.stress-link');
  const detailsSection = document.getElementById('technique-details');
  const backButton = document.getElementById('back-button');
  const allContents = document.querySelectorAll('#technique-details > div');

  techniqueLinks.forEach((link, index) => {
    link.addEventListener('click', (event) => {
      event.preventDefault();
      const technique = event.target.closest('li').dataset.technique;
      detailsSection.classList.remove('hidden');
      document.getElementById(`${technique}-content`).classList.remove('hidden');
    });
  });

  // Back Button to Hide Details
  backButton.addEventListener('click', () => {
    detailsSection.classList.add('hidden');
    allContents.forEach(content => content.classList.add('hidden'));
  });
  const tips = [
    "Take deep breaths and count to ten.",
    "Step outside for some fresh air.",
    "Write down your thoughts to clear your mind.",
    "Drink a glass of water and take a break.",
    "Stretch for 5 minutes to release tension."
  ];

  document.getElementById('tip-button').addEventListener('click', () => {
    const randomIndex = Math.floor(Math.random() * tips.length);
    document.getElementById('random-tip-text').innerText = tips[randomIndex];
  });

  // Search Functionality
  document.getElementById('search-button').addEventListener('click', () => {
    const searchValue = document.getElementById('search-bar').value.toLowerCase();
    const listItems = document.querySelectorAll('#techniques-list li');
    listItems.forEach(item => {
      const text = item.innerText.toLowerCase();
      if (text.includes(searchValue)) {
        item.style.display = '';
      } else {
        item.style.display = 'none';
      }
    });
  });

  // Add New Technique
  document.getElementById('add-technique-button').addEventListener('click', () => {
    const title = document.getElementById('new-technique').value;
    const description = document.getElementById('new-description').value;

    if (title && description) {
      const newLi = document.createElement('li');
      newLi.innerHTML = `
        <img src="default.jpg" alt="New Technique" />
        <a href="#0" class="stress-link">${title}</a>
        <p>${description}</p>
      `;
      document.getElementById('techniques-list').appendChild(newLi);

      // Clear input fields
      document.getElementById('new-technique').value = '';
      document.getElementById('new-description').value = '';
    } else {
      alert('Please fill in both fields!');
    }
  });
  function updateWordCount() {
    const text = document.getElementById('journal-entry').value;
    const wordCount = text.trim().split(/\s+/).length;
    document.getElementById('word-count').textContent = `Word Count: ${wordCount}`;
  }
  
  // Auto-Save Journal Entry
  document.getElementById('journal-entry').addEventListener('input', function() {
    const entry = this.value;
    localStorage.setItem('autoSavedEntry', entry); // Auto-save entry in localStorage
  });
  
  // Handle Form Submission and Save Entry
  document.getElementById('journal-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const entry = document.getElementById('journal-entry').value;
    const attachment = document.getElementById('journal-attachment').files[0];
    const date = new Date().toLocaleDateString();
  
    // Display save animation
    const saveButton = document.getElementById('save-entry');
    saveButton.textContent = 'Saving...';
    saveButton.disabled = true;
  
    setTimeout(() => {
      saveButton.textContent = 'Save Entry';
      saveButton.disabled = false;
      alert(`Journal Entry Saved!\nDate: ${date}\nEntry: ${entry}\nAttachment: ${attachment ? attachment.name : 'None'}`);
      document.getElementById('journal-entry').value = ''; // Clear the entry after saving
      document.getElementById('journal-attachment').value = ''; // Clear attachment
    }, 1500); // Simulate a save delay of 1.5 seconds
  });
  
  // Display Auto-Saved Entry if Available
  window.addEventListener('load', function() {
    const savedEntry = localStorage.getItem('autoSavedEntry');
    if (savedEntry) {
      document.getElementById('journal-entry').value = savedEntry;
    }
  });