document.addEventListener('DOMContentLoaded', function() {
    const currentUser = localStorage.getItem('userId');
    let currentRoom = null;
    let currentAnonymousName = null;
    
    // Connect to Socket.IO
    const socket = io();

    if (!currentUser) {
        window.location.href = '/';
        return;
    }

    // Initialize topic cards
    document.querySelectorAll('.topic-card').forEach(card => {
        card.addEventListener('click', async function() {
            const topic = this.dataset.topic;
            try {
                const createRoomResponse = await fetch('/api/create-room', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ 
                        topic,
                        description: this.querySelector('p').textContent
                    })
                });
                const roomData = await createRoomResponse.json();
                joinRoom(roomData._id, topic);
            } catch (error) {
                console.error('Error creating/joining room:', error);
            }
        });
    });

    async function joinRoom(roomId, topic) {
        currentRoom = roomId;
        
        // Join socket room
        socket.emit('join room', { roomId, userId: currentUser });
        
        // Update UI
        document.getElementById('topic-view').style.display = 'none';
        document.getElementById('chat-view').style.display = 'block';
        document.getElementById('current-topic').textContent = topic;
        
        // Load existing messages
        loadMessages(roomId);
    }

    async function loadMessages(roomId) {
        try {
            const response = await fetch(`/api/messages/${roomId}`);
            const messages = await response.json();
            
            const chatMessages = document.querySelector('.chat-messages');
            chatMessages.innerHTML = '';
            
            messages.forEach(message => {
                addMessageToChat(message, message.userId === currentUser);
            });
        } catch (error) {
            console.error('Error loading messages:', error);
        }
    }

    function addMessageToChat(message, isSender = false) {
        const chatMessages = document.querySelector('.chat-messages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isSender ? 'sent' : 'received'}`;
        messageDiv.textContent = `${message.anonymousName}: ${message.content}`;
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Handle incoming messages
    socket.on('chat message', function(message) {
        // Check if the message is from the current user
        const isSender = message.userId === currentUser;
        addMessageToChat({
            anonymousName: message.anonymousName,
            content: message.content
        }, isSender);
    });

    // Handle user list updates
    socket.on('update users', function(users) {
        const usersList = document.querySelector('.users-list');
        usersList.innerHTML = '<h3>Users in Room</h3>';
        
        users.forEach(user => {
            const userCard = document.createElement('div');
            userCard.className = 'user-card';
            userCard.textContent = user.anonymousName;
            usersList.appendChild(userCard);
        });
    });

    // Store anonymous name when received from server
    socket.on('user joined', function(data) {
        if (data.userId === currentUser) {
            currentAnonymousName = data.anonymousName;
        }
        addSystemMessage(`${data.anonymousName} joined the room`);
    });

    socket.on('user left', function(data) {
        addSystemMessage(`${data.anonymousName} left the room`);
    });

    function addSystemMessage(message) {
        const chatMessages = document.querySelector('.chat-messages');
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message system';
        messageDiv.textContent = message;
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Send message handler
    document.getElementById('send-message').addEventListener('click', sendMessage);
    
    // Handle enter key
    document.getElementById('message-input').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });

    // Separate function for sending messages
    function sendMessage() {
        const input = document.getElementById('message-input');
        const content = input.value.trim();
        
        if (content && currentRoom) {
            // Emit the message to server
            socket.emit('chat message', {
                roomId: currentRoom,
                message: content
            });
            
            // Clear input
            input.value = '';
        }
    }

    // Add leave room handler
    document.getElementById('leave-room').addEventListener('click', leaveRoom);

    async function leaveRoom() {
        if (currentRoom) {
            try {
                // Emit leave room event
                socket.emit('leave room', {
                    roomId: currentRoom,
                    userId: currentUser
                });

                // Clear messages
                const chatMessages = document.querySelector('.chat-messages');
                chatMessages.innerHTML = '';

                // Reset room state
                currentRoom = null;
                currentAnonymousName = null;

                // Show topic selection view
                document.getElementById('chat-view').style.display = 'none';
                document.getElementById('topic-view').style.display = 'block';

                // Clear the users list
                const usersList = document.querySelector('.users-list');
                usersList.innerHTML = '<h3>Users in Room</h3>';

                // Leave socket room
                socket.emit('leave current room');

            } catch (error) {
                console.error('Error leaving room:', error);
            }
        }
    }
}); 