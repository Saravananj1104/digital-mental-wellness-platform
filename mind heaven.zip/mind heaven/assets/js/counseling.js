document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('session-modal');
    const proceedBtn = document.getElementById('proceed-btn');
    const cancelBtn = document.getElementById('cancel-btn');
    let currentMeetLink = '';

    // Generate random anonymous name
    function generateAnonymousName() {
        const adjectives = [
            'Silent', 'Gentle', 'Brave', 'Calm', 'Wise', 'Kind', 
            'Bright', 'Noble', 'Quiet', 'Peace', 'Hope', 'Light'
        ];
        const nouns = [
            'Star', 'Moon', 'Sun', 'Wind', 'River', 'Ocean', 
            'Forest', 'Cloud', 'Rain', 'Dawn', 'Sky', 'Wave'
        ];
        const randomNum = Math.floor(Math.random() * 1000);
        const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
        const noun = nouns[Math.floor(Math.random() * nouns.length)];
        return `${adj}${noun}${randomNum}`;
    }

    // Handle join session clicks
    document.querySelectorAll('.join-session-btn').forEach(button => {
        button.addEventListener('click', function() {
            const anonymousName = generateAnonymousName();
            currentMeetLink = this.dataset.meet;

            // Show anonymous name in modal
            document.querySelector('.encrypted-name').textContent = anonymousName;
            modal.style.display = 'flex';
        });
    });

    // Handle proceed button click
    proceedBtn.addEventListener('click', function() {
        const anonymousName = document.querySelector('.encrypted-name').textContent;
        window.location.href = `/video-room.html?name=${anonymousName}`;
        modal.style.display = 'none';
    });

    // Handle cancel button click
    cancelBtn.addEventListener('click', function() {
        modal.style.display = 'none';
    });

    // Close modal if clicked outside
    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
}); 