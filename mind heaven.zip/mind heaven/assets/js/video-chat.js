document.addEventListener('DOMContentLoaded', function() {
    const peer = new Peer(generatePeerId(), {
        host: 'localhost',
        port: 3000,
        path: '/peerjs'
    });

    let localStream;
    const localVideo = document.getElementById('local-video');
    const remoteVideo = document.getElementById('remote-video');
    const toggleVideoBtn = document.getElementById('toggle-video');
    const toggleAudioBtn = document.getElementById('toggle-audio');
    const leaveCallBtn = document.getElementById('leave-call');
    
    // Get encrypted name from URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const encryptedName = urlParams.get('name');
    document.querySelector('.participant-name').textContent = encryptedName;

    // Initialize video call
    async function initializeCall() {
        try {
            // Request permissions and get stream
            localStream = await navigator.mediaDevices.getUserMedia({
                video: true,
                audio: true
            });

            // Show local video
            localVideo.srcObject = localStream;

            // Update button states
            updateButtonStates();

            // Handle incoming calls
            peer.on('call', function(call) {
                call.answer(localStream);
                call.on('stream', function(remoteStream) {
                    remoteVideo.srcObject = remoteStream;
                });
            });

            // Handle peer connection
            peer.on('open', function(id) {
                console.log('My peer ID is: ' + id);
            });

            peer.on('error', function(err) {
                console.error('Peer connection error:', err);
                alert('Connection error. Please try again.');
            });

        } catch (error) {
            console.error('Failed to get local stream:', error);
            alert('Failed to access camera/microphone. Please check permissions.');
        }
    }

    // Generate anonymous peer ID
    function generatePeerId() {
        return 'anon_' + Math.random().toString(36).substr(2, 9);
    }

    // Update button states based on track status
    function updateButtonStates() {
        if (localStream) {
            const videoTrack = localStream.getVideoTracks()[0];
            const audioTrack = localStream.getAudioTracks()[0];
            
            toggleVideoBtn.classList.toggle('disabled', !videoTrack.enabled);
            toggleAudioBtn.classList.toggle('disabled', !audioTrack.enabled);
        }
    }

    // Toggle video
    toggleVideoBtn.addEventListener('click', function() {
        if (localStream) {
            const videoTrack = localStream.getVideoTracks()[0];
            videoTrack.enabled = !videoTrack.enabled;
            toggleVideoBtn.classList.toggle('disabled');
            
            // Update button icon
            const icon = toggleVideoBtn.querySelector('.icon');
            icon.textContent = videoTrack.enabled ? '📹' : '🚫';
        }
    });

    // Toggle audio
    toggleAudioBtn.addEventListener('click', function() {
        if (localStream) {
            const audioTrack = localStream.getAudioTracks()[0];
            audioTrack.enabled = !audioTrack.enabled;
            toggleAudioBtn.classList.toggle('disabled');
            
            // Update button icon
            const icon = toggleAudioBtn.querySelector('.icon');
            icon.textContent = audioTrack.enabled ? '🎤' : '🔇';
        }
    });

    // Leave call
    leaveCallBtn.addEventListener('click', function() {
        if (localStream) {
            localStream.getTracks().forEach(track => track.stop());
        }
        if (peer) {
            peer.destroy();
        }
        window.location.href = '/1.html';
    });

    // Handle page unload
    window.addEventListener('beforeunload', function() {
        if (localStream) {
            localStream.getTracks().forEach(track => track.stop());
        }
        if (peer) {
            peer.destroy();
        }
    });

    // Start the call
    initializeCall().catch(error => {
        console.error('Failed to initialize call:', error);
        alert('Failed to start video call. Please try again.');
    });
}); 