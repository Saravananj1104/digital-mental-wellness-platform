document.addEventListener('DOMContentLoaded', function() {
    const video = document.getElementById('webcam');
    const canvas = document.getElementById('overlay');
    const dominantEmotion = document.getElementById('dominant-emotion');
    let isStreaming = false;

    // Start webcam
    async function startWebcam() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ 
                video: true,
                audio: false
            });
            video.srcObject = stream;
            isStreaming = true;
            detectEmotions();
        } catch (err) {
            console.error('Error accessing webcam:', err);
            alert('Unable to access webcam. Please ensure you have granted permission.');
        }
    }

    // Detect emotions
    async function detectEmotions() {
        if (!isStreaming) return;

        try {
            // Create temporary canvas to capture current frame
            const tempCanvas = document.createElement('canvas');
            tempCanvas.width = video.videoWidth;
            tempCanvas.height = video.videoHeight;
            const ctx = tempCanvas.getContext('2d');
            ctx.drawImage(video, 0, 0);

            // Convert to base64
            const imageData = tempCanvas.toDataURL('image/jpeg');

            // Send to server
            const response = await fetch('http://127.0.0.1:5000/detect-emotion', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ image: imageData })
            });

            const result = await response.json();
            
            if (result.dominant_emotion) {
                updateEmotionDisplay(result.dominant_emotion, result.emotions);
            }
        } catch (error) {
            console.error('Error detecting emotions:', error);
        }

        // Continue detection
        setTimeout(detectEmotions, 1000);
    }

    function updateEmotionDisplay(dominant, emotions) {
        // Update dominant emotion
        dominantEmotion.textContent = dominant.toUpperCase();
        dominantEmotion.className = `emotion-${dominant.toLowerCase()}`;

        // Update emotion bars
        Object.entries(emotions).forEach(([emotion, value]) => {
            const bar = document.getElementById(`${emotion.toLowerCase()}-bar`);
            if (bar) {
                const percentage = Math.round(value);
                bar.style.width = `${percentage}%`;
                bar.textContent = `${percentage}%`;
            }
        });
    }

    // Start the webcam when page loads
    startWebcam();
}); 