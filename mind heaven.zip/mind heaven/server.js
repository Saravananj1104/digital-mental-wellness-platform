const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const bodyParser = require('body-parser');
const path = require('path');
const cors = require('cors');
const http = require('http');
const socketIO = require('socket.io');
const { ExpressPeerServer } = require('peer');

// Initialize express app and socket.io
const app = express();
const server = http.createServer(app);
const io = socketIO(server);
const port = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname)));

// Connect to MongoDB with better error handling
mongoose.connect('mongodb://127.0.0.1:27017/loginSignupApp', { 
    useNewUrlParser: true, 
    useUnifiedTopology: true 
})
.then(() => {
    console.log('Connected to MongoDB successfully');
})
.catch((err) => {
    console.error('MongoDB connection error:', err);
});

// Add error handler for MongoDB connection
mongoose.connection.on('error', err => {
    console.error('MongoDB connection error:', err);
});

// Create a User model
const User = mongoose.model('User', new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true }
}));

// Chat related schemas
const ChatRoom = mongoose.model('ChatRoom', new mongoose.Schema({
    topic: { type: String, required: true },
    description: String,
    activeUsers: [{ 
        userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        anonymousName: String,
        avatarColor: String
    }],
    createdAt: { type: Date, default: Date.now }
}));

const Message = mongoose.model('Message', new mongoose.Schema({
    roomId: { type: mongoose.Schema.Types.ObjectId, ref: 'ChatRoom' },
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    anonymousName: String,
    content: String,
    createdAt: { type: Date, default: Date.now }
}));

// Store active users
const activeUsers = new Map(); // roomId -> Set of {userId, anonymousName}

io.on('connection', (socket) => {
    console.log('New client connected');

    socket.on('join room', async ({ roomId, userId }) => {
        try {
            socket.join(roomId);
            
            // Generate anonymous name for the user
            const anonymousName = generateAnonymousName();
            
            // Add user to active users for this room
            if (!activeUsers.has(roomId)) {
                activeUsers.set(roomId, new Set());
            }
            activeUsers.get(roomId).add({ userId, anonymousName, socketId: socket.id });
            
            // Emit updated user list to all clients in the room
            const roomUsers = Array.from(activeUsers.get(roomId)).map(user => ({
                anonymousName: user.anonymousName
            }));
            
            io.to(roomId).emit('update users', roomUsers);
            
            // Send join message with userId for identification
            io.to(roomId).emit('user joined', { anonymousName, userId });
            
            // Save user's anonymous name
            socket.anonymousName = anonymousName;
            socket.currentRoom = roomId;
            socket.userId = userId;
        } catch (error) {
            console.error('Error joining room:', error);
        }
    });

    socket.on('chat message', async ({ roomId, message }) => {
        try {
            const newMessage = new Message({
                roomId,
                userId: socket.userId,
                anonymousName: socket.anonymousName,
                content: message
            });
            await newMessage.save();
            
            // Broadcast to everyone in the room including sender
            io.to(roomId).emit('chat message', {
                anonymousName: socket.anonymousName,
                content: message,
                userId: socket.userId,  // Add userId to identify sender
                isSender: false
            });
        } catch (error) {
            console.error('Error sending message:', error);
        }
    });

    socket.on('leave room', async ({ roomId, userId }) => {
        try {
            // Remove user from active users
            const roomUsers = activeUsers.get(roomId);
            if (roomUsers) {
                roomUsers.delete(Array.from(roomUsers).find(u => u.socketId === socket.id));
                
                // Update remaining users list
                const remainingUsers = Array.from(roomUsers).map(user => ({
                    anonymousName: user.anonymousName
                }));
                io.to(roomId).emit('update users', remainingUsers);
            }

            // Remove user from room in database
            await ChatRoom.findByIdAndUpdate(roomId, {
                $pull: { activeUsers: { userId: userId } }
            });

            // Clear messages for this room
            await Message.deleteMany({ roomId: roomId });

            // Notify other users
            socket.to(roomId).emit('user left', {
                anonymousName: socket.anonymousName
            });

            // Leave the socket room
            socket.leave(roomId);

            // Clear socket data
            socket.currentRoom = null;
            socket.anonymousName = null;

        } catch (error) {
            console.error('Error leaving room:', error);
        }
    });

    socket.on('leave current room', () => {
        if (socket.currentRoom) {
            socket.leave(socket.currentRoom);
        }
    });

    socket.on('disconnect', () => {
        if (socket.currentRoom && socket.anonymousName) {
            const roomUsers = activeUsers.get(socket.currentRoom);
            if (roomUsers) {
                roomUsers.delete(Array.from(roomUsers).find(u => u.socketId === socket.id));
                
                // Emit updated user list
                const remainingUsers = Array.from(roomUsers).map(user => ({
                    anonymousName: user.anonymousName
                }));
                io.to(socket.currentRoom).emit('update users', remainingUsers);
                
                // Emit leave message
                socket.to(socket.currentRoom).emit('user left', {
                    anonymousName: socket.anonymousName
                });
            }
        }
        console.log('Client disconnected');
    });
});

// Signup Route
app.post('/signup', async (req, res) => {
    try {
        console.log('Received signup request:', req.body);
        
        const { username, email, password } = req.body;
        
        if (!username || !email || !password) {
            console.log('Missing required fields');
            return res.status(400).json({ message: 'All fields are required' });
        }
        
        // Check if the username or email already exists
        const existingUser = await User.findOne({ $or: [{ username }, { email }] });
        if (existingUser) {
            console.log('User already exists');
            return res.status(400).json({ message: 'Username or Email already exists' });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Save the new user to the database
        const user = new User({ username, email, password: hashedPassword });
        await user.save();
        console.log('User saved successfully');

        res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
        console.error('Detailed signup error:', error);
        res.status(500).json({ message: 'Server error during signup. Please try again.' });
    }
});

// Login Route
app.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;

        // Find user by username
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(400).json({ message: 'User not found' });
        }

        // Compare password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: 'Invalid password' });
        }

        res.status(200).json({ 
            message: 'Login successful',
            redirectUrl: '/dashboard',
            userId: user._id
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ message: 'Server error during login' });
    }
});

// Add this route to serve the login page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));
});

// Add route to serve index.html
app.get('/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Chat room routes
app.get('/api/topics', async (req, res) => {
    try {
        const rooms = await ChatRoom.find().select('topic description activeUsers');
        res.json(rooms);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching topics' });
    }
});

app.post('/api/join-room', async (req, res) => {
    try {
        const { userId, roomId } = req.body;
        const anonymousName = generateAnonymousName();
        const avatarColor = generateRandomColor();

        await ChatRoom.findByIdAndUpdate(roomId, {
            $push: { activeUsers: { userId, anonymousName, avatarColor } }
        });

        res.json({ anonymousName, avatarColor });
    } catch (error) {
        res.status(500).json({ message: 'Error joining room' });
    }
});

app.post('/api/messages', async (req, res) => {
    try {
        const { roomId, userId, anonymousName, content } = req.body;
        const message = new Message({ roomId, userId, anonymousName, content });
        await message.save();
        res.status(201).json(message);
    } catch (error) {
        res.status(500).json({ message: 'Error sending message' });
    }
});

app.get('/api/messages/:roomId', async (req, res) => {
    try {
        const messages = await Message.find({ roomId: req.params.roomId })
            .sort({ createdAt: -1 })
            .limit(50);
        res.json(messages.reverse());
    } catch (error) {
        res.status(500).json({ message: 'Error fetching messages' });
    }
});

// Add this with other chat room routes
app.post('/api/create-room', async (req, res) => {
    try {
        const { topic, description } = req.body;
        let room = await ChatRoom.findOne({ topic });
        
        if (!room) {
            room = new ChatRoom({ topic, description });
            await room.save();
        }
        
        res.json(room);
    } catch (error) {
        res.status(500).json({ message: 'Error creating chat room' });
    }
});

// Add this with other chat room routes
app.delete('/api/messages/:roomId', async (req, res) => {
    try {
        await Message.deleteMany({ roomId: req.params.roomId });
        res.status(200).json({ message: 'Messages cleared successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Error clearing messages' });
    }
});

// Add this with your other routes
app.get('/chatbot', (req, res) => {
    res.sendFile(path.join(__dirname, 'chatbot.html'));
});

// Helper functions
function generateAnonymousName() {
    const adjectives = ['Happy', 'Brave', 'Wise', 'Kind', 'Calm', 'Bright'];
    const nouns = ['Panda', 'Tiger', 'Eagle', 'Dolphin', 'Fox', 'Wolf'];
    return `${adjectives[Math.floor(Math.random() * adjectives.length)]}${nouns[Math.floor(Math.random() * nouns.length)]}`;
}

function generateRandomColor() {
    const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEEAD', '#D4A5A5'];
    return colors[Math.floor(Math.random() * colors.length)];
}

// Add after creating the http server
const peerServer = ExpressPeerServer(server, {
    path: '/peerjs'
});

app.use('/peerjs', peerServer);

// Change app.listen to server.listen
server.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
